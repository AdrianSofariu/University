#pragma once
#include "Movie.h"

class MovieValidator
{
public:
	static void validateMovie(const Movie movie);
};

