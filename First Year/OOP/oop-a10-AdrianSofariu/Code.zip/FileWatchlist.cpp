#include "FileWatchlist.h"

void FileWatchlist::setFilename(const std::string& filename)
{
	this->filename = filename;
}
