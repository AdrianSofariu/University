#include "Movie.h"
#include "Repository.h"
#include "TextFileRepository.h"
#include "Service.h"
#include "UserService.h"
#include "UserInterface.h"
#include <iostream>

int main()
{
	//tests
	{
		/*testMovie();
		testRepository();
		testService();
		testUserService();*/
	}

	//run
	{
		//try {
			TextFileRepository repo{ "Movies.txt" };
			//Repository repo;
			Repository watchlist;
			Service service{ repo };
			UserService uservice{ repo, watchlist };
			UserInterface ui{ service, uservice };
			ui.run();
		//}
		//catch (std::exception& e)
		//{
		//	std::cout << "Repository file cannot be opened!";
		//}
		
	}

	_CrtDumpMemoryLeaks();
	return 0;
}